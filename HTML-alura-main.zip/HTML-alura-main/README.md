# HTML-alura
<h1>Sobre a Barbearia Alura</h1>

<P>Localizada no coração da cidade a Barbearia Alura traz para o mercado o que há de melhor para o seu cabelo e barba. Fundada em 2019, a Barbearia Alura já é destaque na cidade e conquista novos clientes a cada dia.</P>

<P>Nossa missão é: "Proporcionar auto-estima e qualidade de vida aos clientes".</P>

<P>Oferecemos profissionais experientes e antenados às mudanças no mundo da moda. O atendimento possui padrão de excelência e agilidade, garantindo qualidade e satisfação dos nossos clientes.</P>

